# https://koenderks.github.io/aRtsy/
library(aRtsy)

set.seed(156) 
fillin <- canvas_maze(color = "#fafafa", background = "white")
saveCanvas(artwork, filename = "~/docs/templates/LaTeX/2024-02-06-business_report/images/fillin.jpg")



set.seed(156)
artwork <- canvas_collatz(colors = colorPalette("shell3"),
                          background = "white",
                          n = 77,   
                          angle.even = 0.0496,
                          angle.odd = 0.0022,)
saveCanvas(artwork, filename = "~/docs/templates/LaTeX/2024-02-06-business_report/images/cover.png")

